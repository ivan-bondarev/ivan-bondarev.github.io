# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 6.x     | :white_check_mark: |
| < 5.0   | :x:                |

## Reporting a Vulnerability

Please feel free to email us at contact@get.foundation with any details about a vulnerability that you may have found.
