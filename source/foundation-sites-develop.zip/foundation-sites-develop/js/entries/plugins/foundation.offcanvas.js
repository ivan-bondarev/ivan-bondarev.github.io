import { Foundation } from './foundation.core';

import { OffCanvas } from '../../foundation.offcanvas';
Foundation.plugin(OffCanvas, 'OffCanvas');

export { Foundation, OffCanvas };
