import { Foundation } from './foundation.core';

import { ResponsiveMenu } from '../../foundation.responsiveMenu';
Foundation.plugin(ResponsiveMenu, 'ResponsiveMenu');

export { Foundation, ResponsiveMenu };
