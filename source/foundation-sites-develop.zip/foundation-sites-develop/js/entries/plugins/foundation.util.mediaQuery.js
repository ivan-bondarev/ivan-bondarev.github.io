import { Foundation } from './foundation.core';
import { MediaQuery } from '../../foundation.util.mediaQuery';

Foundation.MediaQuery = MediaQuery;
Foundation.MediaQuery._init();

export { Foundation, MediaQuery };
